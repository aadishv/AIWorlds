# high-stakes > 2025-04-16 7:42pm
https://universe.roboflow.com/3151a/high-stakes-wnyrk

Provided by a Roboflow user
License: CC BY 4.0

